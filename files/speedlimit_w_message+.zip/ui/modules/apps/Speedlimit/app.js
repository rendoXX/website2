//Code written by Zeit
//Do not use or edit this code without permission

angular.module('beamng.apps')
.directive('speedlimit', [function () {
  return {
	templateUrl: '/ui/modules/apps/speedlimit/app.html',
  	link: function (scope, element) {

    var blockUpdates = false
    var limit = 0
    var unit = localStorage.getItem('apps:SpeedLimit.unit') || 0
    if (typeof unit == "undefined") unit = 0
    var design = localStorage.getItem('apps:SpeedLimit.design') || 0
    if (typeof design == "undefined") design = 0

    var c = element[0];
    c.addEventListener('contextmenu', function () {
      unit++;
      unit %= 2;
      localStorage.setItem('apps:SpeedLimit.unit', unit)

      document.getElementById("speedLimitTextDesign1").innerText = unit==0?"km/h":"mph"
      document.getElementById("speedLimitTextDesign2").innerText = unit==0?"km/h":"mph"
      document.getElementById("speedLimitTextDesign3").innerText = unit==0?"km/h":"mph"
    }, false);

    c.addEventListener('click', function () {
      design++;
      design %= 3;
      updateDesign(design)
      localStorage.setItem('apps:SpeedLimit.design', design)
    }, false);

    c.addEventListener('mouseover', function () {
      blockUpdates = true
      document.getElementById("speedLimitTextDesign1").innerText = unit==0?"km/h":"mph"
      document.getElementById("speedLimitTextDesign2").innerText = unit==0?"km/h":"mph"
      document.getElementById("speedLimitTextDesign3").innerText = unit==0?"km/h":"mph"

      console.info(c.style.height)
    }, false);

    c.addEventListener('mouseleave', function () {
      blockUpdates = false
      updateLimit()
    }, false);

    function updateLimit() {
      if (blockUpdates) { return }
      var speed = (unit == 0 ? (limit * 3.6) : (limit / 0.44704)).toFixed(0); // No rounding to nearest 10
      if (speed == 0) speed = "--"
      document.getElementById("speedLimitTextDesign1").innerText = speed
      document.getElementById("speedLimitTextDesign2").innerText = speed
      document.getElementById("speedLimitTextDesign3").innerText = speed
    }

    function updateDesign(design) {
      document.getElementById("designMain1").style.opacity = design==0?1:0
      document.getElementById("designMain2").style.opacity = design==1?1:0
      document.getElementById("designMain3").style.opacity = design==2?1:0
    }

    function resize(height_) {
      document.getElementById("speedLimitTextDesign1").style.fontSize = height_ * 2.2 + "%"

      document.getElementById("speedLimitSpan").style.marginTop = height_ / 29 + "%"
      document.getElementById("speedLimitSpan").style.fontSize = height_ + 10 + "%"
      document.getElementById("speedLimitSpan1").style.fontSize = height_ + 10 + "%"
      document.getElementById("speedLimitTextDesign2").style.fontSize = height_ * 2.2 + "%"

      document.getElementById("limitSpan1").style.fontSize = height_ + 50 + "%"
      document.getElementById("speedLimitTextDesign3").style.fontSize = height_ * 2.2 + "%"
    }

    scope.$on('speedLimitActive', function (event, data) {
      updateDesign(design);
    })

    scope.$on('updateSpeedLimit', function (event, data) {
      limit = data[0]
      updateLimit(limit)
    })

    scope.$on('app:resized', function (event, data) {
      resize(data.height)
    })

    scope.$on('$destroy', function () {
      bngApi.engineLua("extensions.unload('speedlimit_Speedlimit')")
    })
    resize(c.style.height);
    bngApi.engineLua("extensions.reload('speedlimit_Speedlimit')")
}}}]);
