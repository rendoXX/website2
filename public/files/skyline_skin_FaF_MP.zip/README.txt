These files are made to replace bodycolored trim paint_design for pessima.
Use this if you play multiplayer and want to see this skin but others that dont have this mod see bodycolored trim, instead of just black trim.

Simply drag and replace these files in: steam\steamapps\common\BeamNG.drive\content\vehicles/pessima.zip/vehicles/pessima